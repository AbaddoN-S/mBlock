http://robotclass.ru/tutorials/arduino-radio-433mhz/

https://arduinomaster.ru/program/preryvaniya-arduino-attachinterrupt/

