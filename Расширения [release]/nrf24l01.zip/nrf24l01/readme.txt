https://3d-diy.ru/wiki/arduino-moduli/radio-modul-nrf24l01/

https://github.com/nRF24/RF24